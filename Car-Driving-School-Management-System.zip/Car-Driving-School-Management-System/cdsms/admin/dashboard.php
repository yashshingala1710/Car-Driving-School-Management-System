<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['cdsmsaid']==0)) {
  header('location:logout.php');
  } 
     ?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>CDSMS Admin Dashboard</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/admin-custom.css">
    <link rel="stylesheet" href="../css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <style>
        .stat-card {
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            margin-bottom: 25px;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card .card-body {
            padding: 25px;
        }
        .stat-icon {
            font-size: 40px;
            margin-bottom: 15px;
            opacity: 0.8;
        }
        .stat-count {
            font-size: 36px;
            font-weight: 700;
            margin-bottom: 10px;
        }
        .stat-label {
            font-size: 16px;
            opacity: 0.9;
            margin-bottom: 0;
        }
        .bg-gradient-primary {
            background: linear-gradient(45deg, #4099ff, #73b4ff);
        }
        .bg-gradient-success {
            background: linear-gradient(45deg, #2ed8b6, #59e0c5);
        }
        .bg-gradient-warning {
            background: linear-gradient(45deg, #FFB64D, #ffcb80);
        }
        .bg-gradient-danger {
            background: linear-gradient(45deg, #FF5370, #ff869a);
        }
        .stat-card .progress {
            height: 6px;
            margin-top: 15px;
            background-color: rgba(255,255,255,0.2);
        }
        .stat-card .progress-bar {
            background-color: rgba(255,255,255,0.8);
        }
    </style>
</head>

<body>
    <?php include_once('includes/sidebar.php');?>

    <div id="right-panel" class="right-panel">
        <?php include_once('includes/header.php');?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <a href="new-application.php" class="text-decoration-none">
                            <div class="card text-white bg-gradient-primary stat-card">
                                <div class="card-body">
                                    <div class="stat-icon">
                                        <i class="fa fa-file-text"></i>
                                    </div>
                                    <?php 
                                    $query=mysqli_query($con,"Select * from  tblapplication where Status is null");
                                    $newapp=mysqli_num_rows($query);
                                    ?>
                                    <div class="stat-count"><?php echo $newapp;?></div>
                                    <p class="stat-label">New Applications</p>
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 70%"></div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <a href="approved-application.php" class="text-decoration-none">
                            <div class="card text-white bg-gradient-success stat-card">
                                <div class="card-body">
                                    <div class="stat-icon">
                                        <i class="fa fa-check-circle"></i>
                                    </div>
                                    <?php 
                                    $query1=mysqli_query($con,"Select * from tblapplication where (Status='Approved' || Status='Completed' || Status='Partial Payment')");
                                    $appapli=mysqli_num_rows($query1);
                                    ?>
                                    <div class="stat-count"><?php echo $appapli;?></div>
                                    <p class="stat-label">Approved Applications</p>
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 85%"></div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <a href="cancelled-application.php" class="text-decoration-none">
                            <div class="card text-white bg-gradient-danger stat-card">
                                <div class="card-body">
                                    <div class="stat-icon">
                                        <i class="fa fa-times-circle"></i>
                                    </div>
                                    <?php 
                                    $query2=mysqli_query($con,"Select * from tblapplication where Status='Cancelled'");
                                    $canapp=mysqli_num_rows($query2);
                                    ?>
                                    <div class="stat-count"><?php echo $canapp;?></div>
                                    <p class="stat-label">Cancelled Applications</p>
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 50%"></div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <a href="all-application.php" class="text-decoration-none">
                            <div class="card text-white bg-gradient-warning stat-card">
                                <div class="card-body">
                                    <div class="stat-icon">
                                        <i class="fa fa-files-o"></i>
                                    </div>
                                    <?php 
                                    $query3=mysqli_query($con,"Select * from tblapplication");
                                    $allapp=mysqli_num_rows($query3);
                                    ?>
                                    <div class="stat-count"><?php echo $allapp;?></div>
                                    <p class="stat-label">Total Applications</p>
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 100%"></div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Recent Applications -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Recent Applications</strong>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Registration No</th>
                                                <th>Name</th>
                                                <th>Package</th>
                                                <th>Status</th>
                                                <th>Registration Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $ret=mysqli_query($con,"select tblapplication.ID as lid,tblapplication.FullName,tblapplication.RegNumber,tblapplication.Status,tblapplication.RegDate,tblpackages.PackageName from  tblapplication join tblpackages on tblpackages.ID=tblapplication.PackID order by lid desc limit 5");
                                            $cnt=1;
                                            while ($row=mysqli_fetch_array($ret)) {
                                            ?>
                                            <tr>
                                                <td><?php echo $cnt;?></td>
                                                <td><?php echo $row['RegNumber'];?></td>
                                                <td><?php echo $row['FullName'];?></td>
                                                <td><?php echo $row['PackageName'];?></td>
                                                <td>
                                                    <?php 
                                                    $status = $row['Status'];
                                                    if($status == '') {
                                                        echo '<span class="badge badge-warning">Pending</span>';
                                                    } elseif($status == 'Approved') {
                                                        echo '<span class="badge badge-success">Approved</span>';
                                                    } elseif($status == 'Cancelled') {
                                                        echo '<span class="badge badge-danger">Cancelled</span>';
                                                    } else {
                                                        echo '<span class="badge badge-info">'.$status.'</span>';
                                                    }
                                                    ?>
                                                </td>
                                                <td><?php echo $row['RegDate'];?></td>
                                            </tr>
                                            <?php 
                                            $cnt=$cnt+1;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
