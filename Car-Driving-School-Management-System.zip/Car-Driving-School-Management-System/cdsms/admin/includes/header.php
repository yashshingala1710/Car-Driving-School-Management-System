 <!-- Header-->
<header id="header" class="header">
    <div class="header-menu">
        <div class="col-sm-7">
            <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
            <div class="header-left">
                <div class="form-inline">
                    <form class="search-form">
                        <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                        <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                    </form>
                </div>
                <div class="dropdown for-notification">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="notification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-bell"></i>
                        <?php
                        $ret1 = mysqli_query($con, "select ID,FullName from tblapplication where Status is null");
                        $num = mysqli_num_rows($ret1);

                        ?>   
                        <span class="count bg-danger"><?php echo $num; ?></span>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="notification">
                        <?php if ($num > 0) {
                            while ($result = mysqli_fetch_array($ret1)) {
                        ?>
                                <p>  <a class="dropdown-item" href="view-application-details.php?viewid=<?php echo $result['ID']; ?>">  <i class="fa fa-check"></i>New Application Received from <?php echo $result['FullName']; ?></a></p> 
                        <?php }
                        } else { ?>
                            <a class="dropdown-item" href="all-application.php">No New Application Received</a>
                        <?php } ?>
                    </div>
                </div>
                <div class="dropdown for-message">
                    <button class="btn btn-secondary dropdown-toggle" type="button"
                        id="message"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="ti-email"></i>
                        <?php
                        $ret2 = mysqli_query($con, "select ID,FullName from tblenquiry where Is_Read is null");
                        $num1 = mysqli_num_rows($ret2);

                        ?>
                        <span class="count bg-primary"><?php echo $num1; ?></span>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="message">
                        <a class="dropdown-item media bg-flat-color-1" href="#">
                            <span class="photo media-left"><img alt="avatar" src="images/user.png"></span>
                            <span class="message media-body">
                                <?php if ($num1 > 0) {
                                    while ($result1 = mysqli_fetch_array($ret2)) {
                                ?>
                                        <a class="dropdown-item" href="view-user-enquiry.php?enqid=<?php echo $result1['ID']; ?>">New Enquiry Received from <?php echo $result1['FullName']; ?></a>
                                <?php }
                                } else { ?>
                                    <a class="dropdown-item" href="#">No New Enquiry Received</a>
                                <?php } ?>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-5">
            <div class="user-area dropdown float-right">
                <?php
                $aid = $_SESSION['cdsmsaid'];
                $ret = mysqli_query($con, "select AdminName from tbladmin where ID='$aid'");
                $row = mysqli_fetch_array($ret);
                $name = $row['AdminName'];
                ?>  
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Welcome <?php echo $name; ?>  <i class="fa fa-angle-down"></i>
                </a>
                <div class="user-menu dropdown-menu">
                    <a class="nav-link" href="adminprofile.php"><i class="fa fa-user"></i> My Profile</a>
                    <a class="nav-link" href="change-password.php"><i class="fa fa-cog"></i> Change Password</a>
                    <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>
</header>

<style>
/* Common styles for all admin pages */
.right-panel {
    background: #f1f2f7;
}

.card {
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.card-header {
    background: #fff;
    border-bottom: 1px solid #e6e6e6;
    padding: 15px 20px;
}

.card-body {
    padding: 20px;
}

/* Table styles */
.table {
    background: #fff;
    border-radius: 3px;
    margin-bottom: 0;
}

.table thead th {
    border-bottom: 2px solid #e6e6e6;
    font-weight: 600;
}

.table td, .table th {
    padding: 12px 15px;
    vertical-align: middle;
}

/* Form styles */
.form-control {
    border-radius: 4px;
    border: 1px solid #e6e6e6;
    box-shadow: none;
    height: 42px;
    padding: 8px 15px;
}

.form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
}

/* Button styles */
.btn {
    border-radius: 4px;
    font-weight: 600;
    padding: 8px 16px;
}

.btn-primary {
    background: #007bff;
    border-color: #0056b3;
}

.btn-primary:hover {
    background: #0056b3;
}

/* Badge styles */
.badge {
    padding: 5px 10px;
    border-radius: 30px;
    font-weight: 500;
}

/* Left panel customization */
.left-panel {
    background: #222;
}

.navbar-brand {
    color: #fff !important;
    font-weight: 600;
}

.navbar .navbar-nav li > a {
    color: #878787;
    padding: 10px 20px;
}

.navbar .navbar-nav li > a:hover,
.navbar .navbar-nav li > a:focus,
.navbar .navbar-nav li.active > a {
    color: #fff;
    background: rgba(255,255,255,0.1);
}

.navbar .navbar-nav li .sub-menu {
    background: #1a1a1a;
}

/* Header customization */
.header {
    background: #fff;
    border-bottom: 1px solid #e6e6e6;
}

.header-menu .col-sm-7 {
    display: flex;
    align-items: center;
}

.menutoggle {
    color: #222;
}

.user-area .dropdown-toggle {
    color: #222;
    font-weight: 500;
}

/* Breadcrumbs */
.breadcrumbs {
    background: #fff;
    margin-bottom: 20px;
    padding: 15px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.page-header {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
}
</style>