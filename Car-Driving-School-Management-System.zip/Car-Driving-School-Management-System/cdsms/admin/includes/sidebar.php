<!-- Left Panel -->
<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">
        <div class="navbar-header">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="dashboard.php">
                <i class="fa fa-car"></i> CDSMS Admin
            </a>
        </div>

        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="dashboard.php"> 
                        <i class="menu-icon fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                        <i class="menu-icon fa fa-tasks"></i>
                        <span>Packages</span>
                    </a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-plus"></i><a href="add-package.php">Add Package</a></li>
                        <li><i class="menu-icon fa fa-list"></i><a href="manage-package.php">Manage Package</a></li>
                    </ul>
                </li>

                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                        <i class="menu-icon fa fa-file-text"></i>
                        <span>Applications</span>
                    </a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-plus"></i><a href="new-application.php">New Applications</a></li>
                        <li><i class="menu-icon fa fa-check"></i><a href="approved-application.php">Approved</a></li>
                        <li><i class="menu-icon fa fa-times"></i><a href="cancelled-application.php">Cancelled</a></li>
                        <li><i class="menu-icon fa fa-list"></i><a href="all-application.php">All Applications</a></li>
                    </ul>
                </li>

                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                        <i class="menu-icon fa fa-credit-card"></i>
                        <span>Payments</span>
                    </a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-check"></i><a href="full-payment.php">Full Payment</a></li>
                        <li><i class="menu-icon fa fa-clock-o"></i><a href="partial-payment.php">Partial Payment</a></li>
                        <li><i class="menu-icon fa fa-times"></i><a href="no-payment.php">No Payment</a></li>
                    </ul>
                </li>

                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                        <i class="menu-icon fa fa-users"></i>
                        <span>Users</span>
                    </a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-users"></i><a href="registered-users.php">Registered Users</a></li>
                        <li><i class="menu-icon fa fa-bell"></i><a href="subscribed-users.php">Subscribed Users</a></li>
                    </ul>
                </li>

                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                        <i class="menu-icon fa fa-question-circle"></i>
                        <span>Enquiries</span>
                    </a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-plus"></i><a href="new-user-enquiry.php">New Enquiries</a></li>
                        <li><i class="menu-icon fa fa-history"></i><a href="old-user-enquiry.php">Old Enquiries</a></li>
                    </ul>
                </li>

                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                        <i class="menu-icon fa fa-file-text"></i>
                        <span>Reports</span>
                    </a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-calendar"></i><a href="bwdates-report-ds.php">Date Reports</a></li>
                        <li><i class="menu-icon fa fa-money"></i><a href="bwdates-report-paymentsds.php">Payment Reports</a></li>
                    </ul>
                </li>

                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                        <i class="menu-icon fa fa-cog"></i>
                        <span>Settings</span>
                    </a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-info-circle"></i><a href="about-us.php">About Us</a></li>
                        <li><i class="menu-icon fa fa-phone"></i><a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</aside>