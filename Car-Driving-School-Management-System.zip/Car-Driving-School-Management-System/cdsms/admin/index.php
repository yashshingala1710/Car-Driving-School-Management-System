<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['login']))
{
    $adminuser=$_POST['username'];
    $password=md5($_POST['password']);
    $query=mysqli_query($con,"select ID from tbladmin where UserName='$adminuser' && Password='$password'");
    $ret=mysqli_fetch_array($query);
    if($ret>0){
        $_SESSION['cdsmsaid']=$ret['ID'];
        header('location:dashboard.php');
    } else {
        echo "<script>alert('Invalid Details. Please try again.');</script>";
    }
}

// Reset Admin Credentials
if(isset($_POST['reset']))
{
    $currentUser = $_POST['currentUsername'];
    $currentPass = md5($_POST['currentPassword']);
    $newUser = $_POST['newUsername'];
    $newPass = md5($_POST['newPassword']);
    
    // Verify current credentials
    $verify = mysqli_query($con, "SELECT ID from tbladmin where UserName='$currentUser' && Password='$currentPass'");
    if(mysqli_num_rows($verify) > 0) {
        // Update credentials
        $update = mysqli_query($con, "UPDATE tbladmin SET UserName='$newUser', Password='$newPass' WHERE UserName='$currentUser'");
        if($update) {
            echo "<script>alert('Admin credentials updated successfully!');</script>";
        } else {
            echo "<script>alert('Failed to update credentials. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Current username or password is incorrect!');</script>";
    }
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>CDSMS Admin Login</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body style="background: linear-gradient(120deg, #FF416C 0%, #FF4B2B 100%);">
    <div class="sufee-login d-flex align-items-center justify-content-center min-vh-100">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6">
                    <div class="text-center mb-5">
                        <h2 style="color: white; font-weight: 700; text-shadow: 2px 2px 4px rgba(0,0,0,0.2);">Car Driving School Management</h2>
                        <p style="color: rgba(255,255,255,0.9);">Admin Portal Login</p>
                    </div>
                    <div class="card border-0" style="background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); border-radius: 15px; box-shadow: 0 15px 35px rgba(0,0,0,0.2);">
                        <div class="card-body p-5">
                            <!-- Login Form -->
                            <form action="" method="post" name="login" id="loginForm">
                                <div class="form-floating mb-4">
                                    <input type="text" name="username" class="form-control" id="floatingUsername" placeholder=" " required="true">
                                    <label for="floatingUsername"><i class="fa fa-user"></i> Username</label>
                                </div>
                                <div class="form-floating mb-4">
                                    <input type="password" name="password" class="form-control" id="floatingPassword" placeholder=" " required="true">
                                    <label for="floatingPassword"><i class="fa fa-lock"></i> Password</label>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mb-4">
                                    <a href="../index.php" class="text-decoration-none">
                                        <i class="fa fa-home"></i> Back to Home
                                    </a>
                                    <a href="#" onclick="toggleForms()" class="text-decoration-none">
                                        <i class="fa fa-key"></i> Change Credentials
                                    </a>
                                </div>
                                <button type="submit" class="btn btn-primary w-100 py-3" name="login" style="font-size: 1.1rem;">
                                    <i class="fa fa-sign-in"></i> Sign in
                                </button>
                            </form>

                            <!-- Reset Credentials Form -->
                            <form action="" method="post" name="reset" id="resetForm" style="display: none;">
                                <div class="form-floating mb-4">
                                    <input type="text" name="currentUsername" class="form-control" id="floatingCurrentUsername" placeholder=" " required>
                                    <label for="floatingCurrentUsername"><i class="fa fa-user"></i> Current Username</label>
                                </div>
                                <div class="form-floating mb-4">
                                    <input type="password" name="currentPassword" class="form-control" id="floatingCurrentPassword" placeholder=" " required>
                                    <label for="floatingCurrentPassword"><i class="fa fa-lock"></i> Current Password</label>
                                </div>
                                <div class="form-floating mb-4">
                                    <input type="text" name="newUsername" class="form-control" id="floatingNewUsername" placeholder=" " required>
                                    <label for="floatingNewUsername"><i class="fa fa-user-plus"></i> New Username</label>
                                </div>
                                <div class="form-floating mb-4">
                                    <input type="password" name="newPassword" class="form-control" id="floatingNewPassword" placeholder=" " required>
                                    <label for="floatingNewPassword"><i class="fa fa-key"></i> New Password</label>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mb-4">
                                    <a href="#" onclick="toggleForms()" class="text-decoration-none">
                                        <i class="fa fa-arrow-left"></i> Back to Login
                                    </a>
                                </div>
                                <button type="submit" class="btn btn-warning w-100 py-3" name="reset" style="font-size: 1.1rem;">
                                    <i class="fa fa-refresh"></i> Update Credentials
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
        function toggleForms() {
            const loginForm = document.getElementById('loginForm');
            const resetForm = document.getElementById('resetForm');
            
            if(loginForm.style.display === 'none') {
                loginForm.style.display = 'block';
                resetForm.style.display = 'none';
            } else {
                loginForm.style.display = 'none';
                resetForm.style.display = 'block';
            }
        }
    </script>
</body>
</html>
