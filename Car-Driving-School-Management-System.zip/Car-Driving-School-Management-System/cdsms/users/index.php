<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['login']))
  {
    $emailcon=$_POST['emailcont'];
    $password=md5($_POST['password']);
    $query=mysqli_query($con,"select ID from tblregusers where  (Email='$emailcon' || MobileNumber='$emailcon') && Password='$password' ");
    $ret=mysqli_fetch_array($query);
    if($ret>0){
      $_SESSION['cdsmsuid']=$ret['ID'];
     header('location:dashboard.php');
    }
    else{
  
    echo "<script>alert('Invalid Details.');</script>";
    }
  }
  ?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>CDSMS User Login</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="../admin/vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../admin/vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../admin/vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../admin/vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../admin/vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="../admin/assets//css/style.css">
    <link rel="stylesheet" href="../css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    
</head>

<body class="login-body">
    <div class="sufee-login d-flex align-items-center justify-content-center min-vh-100 py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-5">
                    <div class="text-center mb-5">
                        <h2 class="login-heading">Welcome Back</h2>
                        <p class="text-white">Sign in to your account</p>
                    </div>
                    <div class="login-card card border-0">
                        <div class="card-body p-5">
                            <form action="" method="post" name="login">
                                <div class="form-floating mb-4">
                                    <input type="text" name="emailcont" class="form-control" id="floatingEmail" placeholder=" " required>
                                    <label for="floatingEmail">Email or Contact Number</label>
                                </div>
                                <div class="form-floating mb-4">
                                    <input type="password" name="password" class="form-control" id="floatingPassword" placeholder=" " required>
                                    <label for="floatingPassword">Password</label>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mb-4">
                                    <a href="../index.php" class="link-hover">
                                        <i class="fa fa-home"></i>
                                        <span>Home</span>
                                    </a>
                                    <a href="forgot-password.php" class="link-hover">Forgot Password?</a>
                                </div>
                                <div class="d-grid gap-2">
                                    <button type="submit" name="login" class="btn btn-lg btn-gradient">
                                        Sign In
                                    </button>
                                </div>
                                <div class="text-center mt-4">
                                    <p class="mb-0">Don't have an account? 
                                        <a href="signup.php" class="link-hover">Sign Up</a>
                                    </p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../admin/vendors/jquery/dist/jquery.min.js"></script>
    <script src="../admin/vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="../admin/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../admin/assets//js/main.js"></script>
</body>

</html>
