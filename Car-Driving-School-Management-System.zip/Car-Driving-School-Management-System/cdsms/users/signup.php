<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['submit']))
  {
    $fname=$_POST['firstname'];
    $lname=$_POST['lastname'];
    $contno=$_POST['mobilenumber'];
    $email=$_POST['email'];
    $password=md5($_POST['password']);

    $ret=mysqli_query($con, "select Email from tblregusers where Email='$email' || MobileNumber='$contno'");
    $result=mysqli_fetch_array($ret);
    if($result>0){

echo '<script>alert("This email or Contact Number already associated with another account")</script>';
    }
    else{
    $query=mysqli_query($con, "insert into tblregusers(FirstName, LastName, MobileNumber, Email, Password) value('$fname', '$lname','$contno', '$email', '$password' )");
    if ($query) {
    
    echo '<script>alert("You have successfully registered")</script>';
  }
  else
    {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }
}
}
  ?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>CDSMS User Signup</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="../admin/vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../admin/vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../admin/vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../admin/vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../admin/vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="../admin/assets//css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>


</head>

<body style="background: linear-gradient(120deg, #FF416C 0%, #FF4B2B 100%);">
    <div class="sufee-login d-flex align-items-center justify-content-center min-vh-100">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6">
                    <div class="text-center mb-5">
                        <h2 style="color: white; font-weight: 700; text-shadow: 2px 2px 4px rgba(0,0,0,0.2);">Welcome to Our Driving School</h2>
                        <p style="color: rgba(255,255,255,0.9);">Create your account to get started</p>
                    </div>
                    <div class="card border-0" style="background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); border-radius: 15px; box-shadow: 0 15px 35px rgba(0,0,0,0.2);">
                        <div class="card-body p-5">
                            <form action="" method="post" name="signup" onsubmit="return checkpass();">
                                <div class="row g-4">
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" name="firstname" class="form-control" id="floatingFirstName" placeholder=" " required>
                                            <label for="floatingFirstName">First Name</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" name="lastname" class="form-control" id="floatingLastName" placeholder=" " required>
                                            <label for="floatingLastName">Last Name</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-floating mb-3">
                                    <input type="text" name="mobilenumber" class="form-control" id="floatingMobile" placeholder=" " maxlength="10" pattern="[0-9]{10}" required>
                                    <label for="floatingMobile">Mobile Number</label>
                                </div>
                                <div class="form-floating mb-3">
                                    <input type="email" name="email" class="form-control" id="floatingEmail" placeholder=" " required>
                                    <label for="floatingEmail">Email Address</label>
                                </div>
                                <div class="row g-4">
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="password" name="password" class="form-control" id="floatingPassword" placeholder=" " required>
                                            <label for="floatingPassword">Password</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="password" name="repeatpassword" class="form-control" id="floatingRepeatPassword" placeholder=" " required>
                                            <label for="floatingRepeatPassword">Repeat Password</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-grid gap-2 mt-4">
                                    <button type="submit" name="submit" class="btn btn-lg" style="background: linear-gradient(to right, #FF416C, #FF4B2B); color: white; font-weight: 600; border: none; transition: all 0.3s; box-shadow: 0 4px 15px rgba(255, 65, 108, 0.3);">
                                        Create Account
                                    </button>
                                </div>
                                <div class="text-center mt-4">
                                    <p class="mb-0" style="color: #666;">Already have an account? 
                                        <a href="index.php" style="color: #FF416C; text-decoration: none; font-weight: 600; transition: color 0.3s;">Sign In</a>
                                    </p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script type="text/javascript">
function checkpass()
{
if(document.signup.password.value!=document.signup.repeatpassword.value)
{
alert('Password and Repeat Password field does not match');
document.signup.repeatpassword.focus();
return false;
}
return true;
} 
</script>
    <script src="../admin/vendors/jquery/dist/jquery.min.js"></script>
    <script src="../admin/vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="../admin/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../admin/assets//js/main.js"></script>
</body>

</html>
